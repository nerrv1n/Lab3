﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3.Tests
{
    [TestClass()]
    public class numTests
    {
        [TestMethod()]
        public void verboseTest()
        {
            var num = new num("2A", MeasureType.hex);
            Assert.AreEqual("42 dec", num.Verbose());
        }

        [TestMethod()]
        public void AddNumberTest()
        {
            var Num1 = new num("2A", MeasureType.hex);
            var Num2 = new num("2", MeasureType.dec);
            var Num = Num1 + Num2;
            Assert.AreEqual("44 dec", Num.Verbose());
        }
        [TestMethod()]
        public void MinByNumberTest()
        {
            var Num1 = new num("2A", MeasureType.hex);
            var Num2 = new num("2", MeasureType.dec);
            var Num = Num1 - Num2;
            Assert.AreEqual("40 dec", Num.Verbose());
        }

        [TestMethod()]
        public void MulByNumberTest()
        {
            var Num1 = new num("2A", MeasureType.hex);
            var Num2 = new num("2", MeasureType.dec);
            var Num = Num1 * Num2;
            Assert.AreEqual("84 dec", Num.Verbose());
        }
        [TestMethod()]
        public void DivByNumberTest()
        {
            var Num1 = new num("2A", MeasureType.hex);
            var Num2 = new num("2", MeasureType.dec);
            var Num = Num1 / Num2;
            Assert.AreEqual("21 dec", Num.Verbose());
        }

        [TestMethod()]
        public void Convert_to_twoTest()
        {
            var Num = new num("15", MeasureType.hex);
            Assert.AreEqual("10101 bin", Num.Verbose());
        }

        [TestMethod()]
        public void Convert_to_eightTest()
        {
            var Num = new num("15", MeasureType.hex);
            Assert.AreEqual("25 octal", Num.Verbose());
        }

        [TestMethod()]
        public void Convert_to_sixteenTest()
        {
            var Num = new num("10101", MeasureType.bin);
            Assert.AreEqual("15 hex", Num.Verbose());
        }

        [TestMethod()]
        public void Convert_to_tenTest()
        {
            var Num = new num("40", MeasureType.octal);
            Assert.AreEqual("32 dec", Num.Verbose());
        }

        [TestMethod()]
        public void convertationTest()
        {
            var Num = new num("40", MeasureType.octal);
            Assert.AreEqual("32 dec", Num.Verbose());
        }
    }
}