﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{

    public partial class Form1 : Form
    {
        private num Sum;
        public Form1()
        {
            InitializeComponent();
            
            var measureItems = new string[]
                {"2","8","10","16"," "};
            var operators = new string[]
                {"+","-","*","/",">=<"};
            
            comboBox1.DataSource = new List<string>(measureItems);
            comboBox2.DataSource = new List<string>(measureItems);
            comboBox3.DataSource = new List<string>(operators);
            comboBox4.DataSource = new List<string>(measureItems);
        }

        private MeasureType GetMeasureType(ComboBox combo)
        {
            MeasureType measureType;
            switch (combo.SelectedIndex)
            {
                case 0:
                    measureType = MeasureType.bin;
                    break;
                case 1:
                    measureType = MeasureType.octal;
                    break;
                case 2:
                    measureType = MeasureType.dec;
                    break;
                case 3:
                    measureType = MeasureType.hex;
                    break;
                default:
                    measureType = MeasureType.dec;
                    break;
            }
            return measureType;
        }

        private void protection(int detector)
        {
            if (detector == 1)
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        for (int i = 0; i < num1.TextLength; i++)
                        {
                            if (((int)num1.Text[i] != 49) && ((int)num1.Text[i] != 48))
                            {
                                MessageBox.Show("Ошибка! Бинарная система счисления может содеражать только 0 и 1!");
                                num1.Text = "";
                            }
                        }
                        break;
                    case 1:
                        for (int i = 0; i < num1.TextLength; i++)
                        {
                            if (((int)num1.Text[i] != 48) && ((int)num1.Text[i] != 49) && ((int)num1.Text[i] != 50) && ((int)num1.Text[i] != 51) && ((int)num1.Text[i] != 52) && ((int)num1.Text[i] != 53) && ((int)num1.Text[i] != 54) && ((int)num1.Text[i] != 55))
                            {
                                MessageBox.Show("Ошибка! Восьмиричная система счисления может содержать числа до 7!");
                                num1.Text = "";
                            }
                        }
                        break;
                    case 3:
                        for (int i = 0; i < num1.TextLength; i++)
                        {
                            if (((int)num1.Text[i] != 48) && ((int)num1.Text[i] != 49) && ((int)num1.Text[i] != 50) && ((int)num1.Text[i] != 51) && ((int)num1.Text[i] != 52) && ((int)num1.Text[i] != 53) && ((int)num1.Text[i] != 54) && ((int)num1.Text[i] != 55) && ((int)num1.Text[i] != 56) && ((int)num1.Text[i] != 57) && ((int)num1.Text[i] != 97) && ((int)num1.Text[i] != 98) && ((int)num1.Text[i] != 99) && ((int)num1.Text[i] != 100) && ((int)num1.Text[i] != 101) && ((int)num1.Text[i] != 102) && ((int)num1.Text[i] != 103))
                            {
                                MessageBox.Show("Ошибка! Шестнадцатиричная система счисления содержит только натуральные числа, а также: a,b,c,d,e,f!");
                                num1.Text = "";
                            }
                        }
                        break;
                }

                if ((num1.Text != "") && (num2.Text != "") && (comboBox4.SelectedIndex != 4) && (comboBox1.SelectedIndex != 4) && (comboBox2.SelectedIndex != 4))
                {
                    if (comboBox3.SelectedIndex != 4)
                    {
                        calculate2();
                        convert_anser();
                        return_value();
                    }
                    else
                    {
                        calculate2();
                    }
                }
            }
            else
            {
                switch (comboBox2.SelectedIndex)
                {
                    case 0:
                        for (int i = 0; i < num2.TextLength; i++)
                        {
                            if (((int)num2.Text[i] != 49) && ((int)num2.Text[i] != 48))
                            {
                                MessageBox.Show("Ошибка! Бинарная система счисления может содеражать только 0 и 1!");
                                num2.Text = "";
                            }
                        }
                        break;
                    case 1:
                        for (int i = 0; i < num2.TextLength; i++)
                        {
                            if (((int)num2.Text[i] != 48) && ((int)num2.Text[i] != 49) && ((int)num2.Text[i] != 50) && ((int)num2.Text[i] != 51) && ((int)num2.Text[i] != 52) && ((int)num2.Text[i] != 53) && ((int)num2.Text[i] != 54) && ((int)num2.Text[i] != 55))
                            {
                                MessageBox.Show("Ошибка! Восьмиричная система счисления может содержать числа до 7!");
                                num2.Text = "";
                            }
                        }
                        break;
                    case 3:
                        for (int i = 0; i < num2.TextLength; i++)
                        {
                            if (((int)num2.Text[i] != 48) && ((int)num2.Text[i] != 49) && ((int)num2.Text[i] != 50) && ((int)num2.Text[i] != 51) && ((int)num2.Text[i] != 52) && ((int)num2.Text[i] != 53) && ((int)num2.Text[i] != 54) && ((int)num2.Text[i] != 55) && ((int)num2.Text[i] != 56) && ((int)num2.Text[i] != 57) && ((int)num2.Text[i] != 97) && ((int)num2.Text[i] != 98) && ((int)num2.Text[i] != 99) && ((int)num2.Text[i] != 100) && ((int)num2.Text[i] != 101) && ((int)num2.Text[i] != 102) && ((int)num2.Text[i] != 103))
                            {
                                MessageBox.Show("Ошибка! Шестнадцатиричная система счисления содержит только натуральные числа, а также: a,b,c,d,e,f!");
                                num2.Text = "";
                            }
                        }
                        break;
                }
                if ((num1.Text != "") && (num2.Text != "") && (comboBox1.SelectedIndex != null) && (comboBox2.SelectedIndex != null) && (comboBox4.SelectedIndex != 4)
                    && (comboBox1.SelectedIndex != 4) && (comboBox2.SelectedIndex != 4))
                {
                    if (comboBox3.SelectedIndex != 4)
                    {
                        calculate2();
                        convert_anser();
                        return_value();
                    }
                    else
                    {
                        calculate2();
                    }
                }
            }
        }
        private void return_value()
        {
            answer.Text = this.Sum.Verbose();
        }

        private void convert_anser()
        {
            switch (comboBox4.SelectedIndex)
            {
                case 0:
                    this.Sum.Convert_to_two();
                    break;
                case 1:
                    this.Sum.Convert_to_eight();
                    break;
                case 2:
                    this.Sum.Convert_to_ten();
                    break;
                case 3:
                    this.Sum.Convert_to_sixteen();
                    break;
                default:
                    this.Sum.Convert_to_ten();
                    break;
            }
        }
        private void calculate2()
        {
            num Num1 = new num(num1.Text, GetMeasureType(comboBox1));
            num Num2 = new num(num2.Text, GetMeasureType(comboBox2));

            try
            {
                switch (comboBox3.Text)
                {
                    case "+":
                        Sum = Num1 + Num2;
                        break;
                    case "-":
                        Sum = Num1 - Num2;
                        break;
                    case "*":
                        Sum = Num1 * Num2;
                        break;
                    case "/":
                        Sum = Num1 / Num2;
                        break;
                    case ">=<":
                        answer.Text=num.comparison(Num1, Num2);
                        comboBox4.SelectedIndex = 4;
                        break;
                    default:
                        Sum = new num("0", MeasureType.dec);
                        break;
                }
                   
            }
            catch (FormatException)
            {
                
            }
        }
        private void num1_TextChanged(object sender, EventArgs e)
        {
            protection(1);
        }
        private void num2_TextChanged(object sender, EventArgs e)
        {
            protection(2);
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            protection(1);
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            protection(2);
        }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            protection(1);
            protection(2);
        }

        private void comboBox4_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            protection(1);
            protection(2);
        }
    }
}
