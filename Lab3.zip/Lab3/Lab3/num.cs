﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    public enum MeasureType { bin, octal, dec, hex };
    public class num 
    {
        private string value;
        private MeasureType type;

        public num(string value, MeasureType type)
        {
            this.value = value;
            this.type = type;
        }

        public void Convert_to_ten()
        {
            switch(this.type)
            {
                case MeasureType.bin:
                    {
                        long temp = Convert.ToInt64(this.value, 2);
                        this.value = Convert.ToString(temp);
                        this.type = MeasureType.dec;
                    }
                    break;
                case MeasureType.octal:
                    {
                        long temp = Convert.ToInt64(this.value, 8);
                        this.value = Convert.ToString(temp);
                        this.type = MeasureType.dec;
                    }
                    break;
                case MeasureType.dec:
                    {
                        long temp = Convert.ToInt64(this.value);
                        this.value = Convert.ToString(temp);
                        this.type = MeasureType.dec;
                    }
                    break;
                case MeasureType.hex:
                    {
                        long temp = Convert.ToInt64(this.value, 16);
                        this.value = Convert.ToString(temp);
                        this.type = MeasureType.dec;
                    }
                    break;
            }
        }
        public void Convert_to_two()
        {
            Convert_to_ten();
            this.value = Convert.ToString(Convert.ToInt64(this.value), 2);
            this.type = MeasureType.bin;
        }

        public void Convert_to_eight()
        {
            Convert_to_ten();
            this.value = Convert.ToString(Convert.ToInt64(this.value), 8);
            this.type = MeasureType.octal;
        }

        public void Convert_to_sixteen()
        {
            Convert_to_ten();
            this.value = Convert.ToString(Convert.ToInt64(this.value), 16);
            this.type = MeasureType.hex;
        }

        public string Verbose()
        {
            return String.Format("{0}",this.value);
        }

        public static num operator +(num instance1,num instance2)
        {
            instance1.Convert_to_ten();
            instance2.Convert_to_ten();
            var NewValue = Convert.ToInt32(instance1.value) + Convert.ToInt32(instance2.value);
            var num = new num(Convert.ToString(NewValue), instance1.type);
            return num;
        }

        public static num operator -(num instance1, num instance2)
        {
            instance1.Convert_to_ten();
            instance2.Convert_to_ten();
            var NewValue = Convert.ToInt32(instance1.value) - Convert.ToInt32(instance2.value);
            var num = new num(Convert.ToString(NewValue), instance1.type);
            return num;
        }

        public static num operator *(num instance1, num instance2)
        {
            instance1.Convert_to_ten();
            instance2.Convert_to_ten();
            var NewValue = Convert.ToInt32(instance1.value) * Convert.ToInt32(instance2.value);
            var num = new num(Convert.ToString(NewValue), instance1.type);
            return num;
        }

        public static num operator /(num instance1, num instance2)
        {
            instance1.Convert_to_ten();
            instance2.Convert_to_ten();
            var NewValue = Convert.ToInt32(instance1.value) / Convert.ToInt32(instance2.value);
            var num = new num(Convert.ToString(NewValue), instance1.type);
            return num;
        }

        public static String comparison(num instance1, num instance2)
        {
            String temp1 = instance1.value;
            String temp2 = instance2.value;
            instance1.Convert_to_ten();
            instance2.Convert_to_ten();
            if(Convert.ToInt32(instance1.value)>Convert.ToInt32(instance2.value))
            {
                return String.Format("{0}>{1}", temp1, temp2);
            }
            else if(Convert.ToInt32(instance1.value) < Convert.ToInt32(instance2.value))
            {
                return String.Format("{0}<{1}", temp1, temp2);
            }
            else
            {
                return String.Format("{0}={1}", temp1, temp2);
            }
        }

    }
}
